package com.example.funweather_temp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
